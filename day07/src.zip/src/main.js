// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import Vuelazyload from "vue-lazyload"

Vue.config.productionTip = false

Vue.use(Vuelazyload, {
    loading: require("../static/images/pp.jpg")
});
/* eslint-disable no-new */
new Vue({
    el: '#app',
    components: { App },
    template: '<App/>'
})