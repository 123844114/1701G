<template>
  <div id="app">
       <header>
         <div class="top">
            <span class="iconfont icon-xiangzuo"></span>
            <input type="text">
            <p>筛选</p>
         </div>
         <ul>
           <li>综合</li>
           <li>销量</li>
           <li @click="priceFn" :class="{active:flag}">价格<span class="iconfont icon-angle-down"></span></li>
           <li>店铺</li>
           <li><span class="iconfont icon-gongzuo"></span></li>
         </ul>
       </header>
       <div class="content">
            <HelloWorld v-for="(item,index) in dataJson.list" :key="index" :options="item"></HelloWorld>
       </div>
    
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld'
import "./fonts/iconfont.css"
import dataJson from "./json/data.json"

export default {
  name: 'App',
  components: {
    HelloWorld
  },
  data(){
    return {
      dataJson,flag:false
    }
  },
  methods:{

    priceFn(){
     if(!this.flag){
          dataJson.list.sort((a,b)=>{
             return a["price"]-b["price"];
          });
           this.flag=true;
     }else{
          dataJson.list.sort((a,b)=>{
             return b["price"]-a["price"];
          });
          this.flag=false;
     }
    }
  }
}
</script>

<style lang="scss" scoped>
#app {
  width:100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  
    header{
      width:100%;
      height: 100px;
      display: flex;
      flex-direction: column;
        .top{
            width:100%;
            height: 50px;
            display: flex;
            justify-content: space-around;
            align-items: center;
            span{
              padding: 0 10px;
              font-size:18px;
            }
            p{
              padding: 0 10px;
              color:#999;
            }
            input{
              border:0;
              outline: none;
              background: #eeeeee;
              height: 30px;
              flex:1;
            }
        }
       
        ul{
          width:100%;
          height: 50px;
          display: flex;
          justify-content: space-around;
          align-items: center;
          li{
            flex:1;
            text-align: center;
            color:#999;
            cursor: pointer;
          }
          li:nth-child(5){
            border-left:1px solid #ccc;
          }
        }
    }
    .content{
      width:100%;
      height: 100%;;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
    }
    .active{
      color:tomato;
    }
  
}
</style>
