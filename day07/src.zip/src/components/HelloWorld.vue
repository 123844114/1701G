<template>
    <dl>
      <!-- <dt><img :src='"../../static/images/" + options.img'></dt> -->
      <dt><img v-lazy='"static/images/" +options.img' ></dt>
      <dd>  
        <h4>{{options.title}}</h4> 
        <p>￥<span>{{options.price}}</span></p>
      </dd>
    </dl>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
    
    }
  },
  props:["options"]
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

    dl{
      width:50%;
      height: auto;
      dt{
        width:100%;
        img{
          width:100%;
        }
      }
      dd{
           width:100%;
        h4{
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        p{
          color:tomato;
        }
      }
    }
    .active{
      color:tomato;
    }
</style>
